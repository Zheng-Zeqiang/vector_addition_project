#include "vector_add.h"

int vector_add(int *a, int *b, int *c)
{
#pragma HLS INTERFACE m_axi port=a offset=slave bundle=DATA1
#pragma HLS INTERFACE m_axi port=b offset=slave bundle=DATA2
#pragma HLS INTERFACE m_axi port=c offset=slave bundle=DATA3
#pragma HLS INTERFACE s_axilite register port=return bundle=ctrl

	int i;
	int arrayA[1024];
	int arrayB[1024];
	int arrayC[1024];

	for(i = 0; i < 1024; i++)
	{
		arrayA[i] = a[i];
		arrayB[i] = b[i];
		arrayC[i] = 0;
	}

	for(i = 0; i < 1024; i++)
	{
		arrayC[i] = arrayA[i]+arrayB[i];
	}

	for(i = 0; i < 1024; i++)
	{
		c[i] = arrayC[i];
	}
	return 0;
}
