#ifndef __VECTOR_ADD__H_
#define __VECTOR_ADD__H_

int vector_add(int *a, int *b, int *c);

#endif
