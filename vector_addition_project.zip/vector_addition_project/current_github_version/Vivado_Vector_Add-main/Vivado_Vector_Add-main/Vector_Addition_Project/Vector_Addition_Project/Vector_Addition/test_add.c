#include "vector_add.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
	int a = rand();
	int b = rand();
	int c = 0;

	c = vector_add(a,b);
	printf("Input %d + %d = %d/n",a,b,c)
}
