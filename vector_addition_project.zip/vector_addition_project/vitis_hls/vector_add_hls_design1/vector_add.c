#include "vector_add.h"

int vector_add(volatile int a[1024], volatile int b[1024], volatile int c[1024])
{
#pragma HLS INTERFACE m_axi depth=1024 port=a offset=slave bundle=DATA1
#pragma HLS INTERFACE m_axi depth=1024 port=b offset=slave bundle=DATA2
#pragma HLS INTERFACE m_axi depth=1024 port=c offset=slave bundle=DATA3
#pragma HLS INTERFACE s_axilite register port=return bundle=ctrl

	int i;
	int arrayA[1024];
	int arrayB[1024];
	int arrayC[1024];

	for(i = 0; i < 1024; i++)
	{
#pragma HLS PIPELINE
		arrayA[i] = a[i];
		arrayB[i] = b[i];
		arrayC[i] = 0;
	}

	for(i = 0; i < 1024; i++)
	{
		arrayC[i] = arrayA[i]+arrayB[i];
	}

	for(i = 0; i < 1024; i++)
	{
#pragma HLS PIPELINE
		c[i] = arrayC[i];
	}
	return 0;
}
